document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();
    alert("Logging in...");
});
